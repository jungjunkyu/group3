package kr.kh.spring.vo;

import lombok.Data;

@Data
public class BoardVO {
	private int bo_num; 
	private String bo_name; 
	private int bo_price;
	
}
